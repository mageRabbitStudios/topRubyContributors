package com.kinzlstanislav.topcontributors.architecture.network

object GitHubRestData {
    const val REST_GITHUB_BASE_URL = "https://api.github.com"
}