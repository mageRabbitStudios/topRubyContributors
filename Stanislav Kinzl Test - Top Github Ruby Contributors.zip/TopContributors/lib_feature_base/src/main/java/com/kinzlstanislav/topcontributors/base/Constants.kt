package com.kinzlstanislav.topcontributors.base

object Constants {
    const val EXTRAS_USER = "extras_user"
    const val EXTRAS_LOCATION = "extras_location"
}