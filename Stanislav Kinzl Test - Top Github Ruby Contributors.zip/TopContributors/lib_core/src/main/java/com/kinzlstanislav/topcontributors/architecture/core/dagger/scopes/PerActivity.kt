package com.kinzlstanislav.topcontributors.architecture.core.dagger.scopes

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity