package com.kinzlstanislav.topcontributors.architecture.core.dagger.qualifiers

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ForApplicationContext